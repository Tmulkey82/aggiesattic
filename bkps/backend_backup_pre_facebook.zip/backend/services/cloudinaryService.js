import dotenv from 'dotenv';
dotenv.config();

import { v2 as cloudinary } from 'cloudinary';

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

export const uploadImage = async (filePath) => {
  const result = await cloudinary.uploader.upload(filePath, {
    folder: 'aggies-attic',
  });
  return result.secure_url;
};

export const deleteImage = async (publicId) => {
  return cloudinary.uploader.destroy(publicId);
};

export const uploadImageWithMeta = async (filePath) => {
  const result = await cloudinary.uploader.upload(filePath, {
    folder: "aggies-attic",
  });

  return {
    url: result.secure_url,
    publicId: result.public_id, // includes folder
  };
};
