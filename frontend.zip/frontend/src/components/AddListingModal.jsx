import { useState } from 'react';
import Modal from './Modal'; // Reusable modal wrapper

export default function AddListingModal({ isOpen, onClose, onAdd }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [imageFiles, setImageFiles] = useState([]);
  const [uploading, setUploading] = useState(false);

  const handleImageUpload = async () => {
    const uploadedUrls = [];

    for (const file of imageFiles) {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('upload_preset', 'aggies_attic_shed'); // Replace with your Cloudinary preset

      const response = await fetch('https://api.cloudinary.com/v1_1/djn1wnlwu/image/upload', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) throw new Error('Image upload failed');

      const data = await response.json();
      uploadedUrls.push(data.secure_url);
    }

    return uploadedUrls;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setUploading(true);
    try {
      const imageUrls = await handleImageUpload();

      const newListing = {
        title,
        description,
        price,
        imageUrls // <-- send array to backend
      };

      const response = await fetch('http://localhost:5001/api/listings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newListing)
      });

      if (!response.ok) throw new Error('Failed to add listing');

      const savedListing = await response.json();
      onAdd(savedListing);
      onClose();
    } catch (error) {
      console.error(error);
      alert('Error adding listing.');
    } finally {
      setUploading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <Modal onClose={onClose}>
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded shadow-md max-w-md w-full">
        <h2 className="text-xl font-bold mb-4">Add New Listing</h2>

        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full border p-2 rounded mb-2"
          required
        />
        <textarea
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full border p-2 rounded mb-2"
          required
        />
        <input
          type="number"
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          className="w-full border p-2 rounded mb-2"
          required
        />
        <input
          type="file"
          accept="image/*"
          multiple
          onChange={(e) => setImageFiles([...e.target.files])}
          className="w-full border p-2 rounded mb-4"
          required
        />

        <div className="flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="bg-gray-300 text-black px-4 py-2 rounded mr-2"
            disabled={uploading}
          >
            Cancel
          </button>
          <button
            type="submit"
            className="bg-green-600 text-white px-4 py-2 rounded"
            disabled={uploading || imageFiles.length === 0}
          >
            {uploading ? 'Uploading...' : 'Add Listing'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
