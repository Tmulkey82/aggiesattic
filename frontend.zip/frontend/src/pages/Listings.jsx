import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import './Listings.css';

const Listings = () => {
  const navigate = useNavigate();
  const { isLoggedIn, login, logout } = useAuth();
  const [listings, setListings] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [error, setError] = useState('');

  const [selectedIndex, setSelectedIndex] = useState(0);
  const [thumbStart, setThumbStart] = useState(0);

  useEffect(() => {
    axios.get('http://localhost:5001/api/listings')
      .then(res => setListings(res.data))
      .catch(err => console.error('Failed to fetch listings', err));
  }, []);

  useEffect(() => {
    const openModal = () => setShowModal(true);
    window.addEventListener('openAdminModal', openModal);
    return () => window.removeEventListener('openAdminModal', openModal);
  }, []);

  useEffect(() => {
  console.log('🔁 isLoggedIn changed:', isLoggedIn);
}, [isLoggedIn]);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const res = await axios.post('http://localhost:5001/api/auth/login', formData);
      console.log('✅ Login success:', res.data); 
      login(res.data.token);
      setShowModal(false);
      setFormData({ email: '', password: '' });
    } catch (err) {
      setError('Invalid credentials');
    }
  };

  const handleMainNav = (dir) => {
    const total = listings.length;
    const newIndex = dir === 'left'
      ? (selectedIndex - 1 + total) % total
      : (selectedIndex + 1) % total;
    setSelectedIndex(newIndex);
  };

  const handleThumbNav = (dir) => {
    const maxStart = Math.max(0, listings.length - 8);
    const newStart = dir === 'left'
      ? Math.max(0, thumbStart - 1)
      : Math.min(maxStart, thumbStart + 1);
    setThumbStart(newStart);
  };

  const visibleThumbnails = listings.slice(thumbStart, thumbStart + 8);

  return (
    <div className="p-6">
        <div className="flex justify-end mb-4">
  {isLoggedIn ? (
    <button
      onClick={logout}
      className="bg-red-600 text-white px-4 py-2 rounded shadow hover:bg-red-700"
    >
      Log Out
    </button>
  ) : (
    <button
      onClick={() => setShowModal(true)}
      className="bg-blue-600 text-white px-4 py-2 rounded shadow hover:bg-blue-700"
    >
      Admin
    </button>
  )}
</div>

      <h1 className="text-2xl font-bold mb-6 text-center">Listings</h1>

      {/* Main Carousel Card */}
      {listings.length > 0 && (
        <div className="flex items-center justify-center mb-6 relative">
          <button
            onClick={() => handleMainNav('left')}
            className="carousel-arrow left-4"
          >
            &lt;
          </button>

          <div
            className="w-full max-w-2xl bg-white rounded shadow overflow-hidden relative cursor-pointer"
            onClick={() => navigate(`/listings/${listings[selectedIndex]._id}`)}
          >
            <div className="relative overflow-hidden">
              <img
                src={
                  listings[selectedIndex].images[listings[selectedIndex].mainImageIndex || 0] ||
                  listings[selectedIndex].images[0]
                }
                alt={listings[selectedIndex].title}
                className="w-full h-80 object-contain bg-gray-100"
              />
              <div className="price-ribbon">
                ${listings[selectedIndex].price}
              </div>
            </div>
            <div className="p-4">
              <h2 className="text-xl font-semibold">{listings[selectedIndex].title}</h2>
              <p className="text-gray-600 text-sm mt-1">{listings[selectedIndex].description}</p>
            </div>
          </div>

          <button
            onClick={() => handleMainNav('right')}
            className="carousel-arrow right-4"
          >
            &gt;
          </button>
        </div>
      )}

      {/* Bottom Thumbnail Carousel */}
      {listings.length > 1 && (
        <div className="flex items-center justify-center mb-8">
          <button onClick={() => handleThumbNav('left')} className="thumb-arrow">&lt;</button>
          <div className="flex gap-3 overflow-hidden w-[1100px]">
            {visibleThumbnails.map((listing, i) => {
              const realIndex = thumbStart + i;
              const img = listing.images[listing.mainImageIndex || 0] || listing.images[0];
              return (
                <div
                  key={listing._id}
                  onClick={() => setSelectedIndex(realIndex)}
                  className={`w-[120px] bg-white rounded shadow cursor-pointer border-2 ${realIndex === selectedIndex ? 'border-orange-500' : 'border-transparent'}`}
                >
                  <img
                    src={img}
                    alt={`thumb-${realIndex}`}
                    className="h-20 w-full object-cover rounded-t"
                  />
                  <div className="px-2 py-1">
                    <h3 className="text-sm font-semibold truncate">{listing.title}</h3>
                  </div>
                </div>
              );
            })}
          </div>
          <button onClick={() => handleThumbNav('right')} className="thumb-arrow">&gt;</button>
        </div>
      )}

      {/* Admin Login Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded shadow-md w-full max-w-sm">
            <h2 className="text-xl font-semibold mb-4">Admin Login</h2>
            {error && <p className="text-red-500 mb-2">{error}</p>}
            <form onSubmit={handleLogin}>
              <input
                type="text"
                placeholder="Email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full border p-2 mb-3"
                required
              />
              <input
                type="password"
                placeholder="Password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full border p-2 mb-4"
                required
              />
              <div className="flex justify-between">
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-4 py-2 rounded"
                >
                  Log In
                </button>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="text-gray-500 hover:underline"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Listings;
